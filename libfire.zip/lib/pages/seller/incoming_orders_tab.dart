import 'package:flutter/material.dart';
import '../../models/order_model.dart';
import '../../services/order_service.dart';
import '../../widgets/order_status_badge.dart';

class IncomingOrdersTab extends StatefulWidget {
  const IncomingOrdersTab({super.key});

  @override
  State<IncomingOrdersTab> createState() => _IncomingOrdersTabState();
}

class _IncomingOrdersTabState extends State<IncomingOrdersTab> {
  final _searchController = TextEditingController();
  final _orderService = OrderService();
  final _ordersScrollController = ScrollController();
  late final Stream<List<OrderModel>> _ordersStream;
  String _search = '';
  String? _expandedOrderId;

  @override
  void initState() {
    super.initState();
    _ordersStream = _orderService.streamAllOrders();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _ordersScrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Align(
          alignment: Alignment.centerLeft,
          child: Text('รายการออเดอร์'),
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 4, 24, 20),
            child: TextField(
              controller: _searchController,
              onChanged: (value) => setState(() => _search = value.trim()),
              style: const TextStyle(color: Colors.black),
              decoration: InputDecoration(
                hintText: 'ค้นหาเลขออเดอร์, ชื่อลูกค้า...',
                hintStyle: const TextStyle(color: Color(0xFF8B7B76)),
                prefixIcon: const Icon(Icons.search, color: Color(0xFF8B7B76)),
                filled: true,
                fillColor: Colors.white,
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(13),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          Expanded(
            child: StreamBuilder<List<OrderModel>>(
              stream: _ordersStream,
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Center(
                    child: Text('โหลดออเดอร์ไม่สำเร็จ: ${snapshot.error}'),
                  );
                }
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                final orders = (snapshot.data ?? [])
                    .where(_matchesSearch)
                    .toList();
                if (orders.isEmpty) {
                  return const Center(child: Text('ไม่พบรายการออเดอร์'));
                }
                return ListView.separated(
                  key: const PageStorageKey<String>('incoming-orders-list'),
                  controller: _ordersScrollController,
                  padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
                  itemCount: orders.length,
                  separatorBuilder: (context, index) =>
                      const SizedBox(height: 14),
                  itemBuilder: (context, index) {
                    final order = orders[index];
                    return _OrderCard(
                      order: order,
                      expanded: _expandedOrderId == order.id,
                      onUpdate: () => setState(() {
                        _expandedOrderId = _expandedOrderId == order.id
                            ? null
                            : order.id;
                      }),
                      onStatusSelected: (status) =>
                          _orderService.updateStatus(order.id, status),
                      onPaymentStatusSelected: (status) =>
                          _orderService.updatePaymentStatus(order.id, status),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  bool _matchesSearch(OrderModel order) {
    if (_search.isEmpty) return true;
    final text = [
      order.id,
      order.customerName,
      order.deliveryAddress,
      ...order.items.map((item) => item['name']?.toString() ?? ''),
    ].join(' ').toLowerCase();
    return text.contains(_search.toLowerCase());
  }
}

class _OrderCard extends StatelessWidget {
  final OrderModel order;
  final bool expanded;
  final VoidCallback onUpdate;
  final Future<void> Function(String status) onStatusSelected;
  final Future<void> Function(String status) onPaymentStatusSelected;

  const _OrderCard({
    required this.order,
    required this.expanded,
    required this.onUpdate,
    required this.onStatusSelected,
    required this.onPaymentStatusSelected,
  });

  @override
  Widget build(BuildContext context) {
    final orderNumber = order.id.length > 3
        ? order.id.substring(order.id.length - 3).toUpperCase()
        : order.id.toUpperCase();
    final customer = order.customerName.isEmpty
        ? 'คุณลูกค้า'
        : order.customerName;

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
      decoration: BoxDecoration(
        color: const Color(0xFFF0321C),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                '#$orderNumber',
                style: const TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w900,
                ),
              ),
              OrderStatusBadge(status: order.status),
            ],
          ),
          const SizedBox(height: 14),
          Text(
            customer,
            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w800),
          ),
          if (order.customerPhone.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(
              'โทร ${order.customerPhone}',
              style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
            ),
          ],
          const SizedBox(height: 10),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: 0.18),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(
                  Icons.location_on_outlined,
                  color: Colors.white,
                  size: 21,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    order.deliveryAddress.isEmpty
                        ? 'ไม่พบที่อยู่จัดส่ง'
                        : order.deliveryAddress,
                    style: const TextStyle(
                      fontSize: 13,
                      height: 1.35,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 2),
          Text(
            'วิธีชำระเงิน: ${_paymentMethodLabel(order.paymentMethod)}'
            ' • สถานะชำระเงิน: ${_paymentLabel(order.paymentStatus)}',
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
          ),
          if (order.paymentStatus != 'paid') ...[
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () async {
                  try {
                    await onPaymentStatusSelected('paid');
                  } catch (error) {
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('อัปเดตการชำระเงินไม่สำเร็จ: $error'),
                        ),
                      );
                    }
                  }
                },
                icon: const Icon(Icons.check_circle_outline, size: 18),
                label: const Text('ทำเครื่องหมายว่า “ชำระแล้ว”'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.white,
                  side: const BorderSide(color: Colors.white),
                ),
              ),
            ),
          ],
          if (order.notes.isNotEmpty)
            Text(
              'หมายเหตุ: ${order.notes}',
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
            ),
          const SizedBox(height: 6),
          Text(
            order.items
                .map((item) => '${item['name']} x${item['qty']}')
                .join(', '),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 13),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 11),
            child: Divider(color: Colors.white, height: 1),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('ยอดรวมสุทธิ', style: TextStyle(fontSize: 12)),
                  Text(
                    order.totalPrice.toStringAsFixed(0),
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
              TextButton(
                onPressed: onUpdate,
                style: TextButton.styleFrom(
                  backgroundColor: Colors.black,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 9,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(11),
                  ),
                ),
                child: const Text(
                  'อัปเดตสถานะ',
                  style: TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
            ],
          ),
          if (expanded) ...[
            const SizedBox(height: 14),
            _StatusActions(status: order.status, onSelected: onStatusSelected),
          ],
        ],
      ),
    );
  }

  String _paymentLabel(String status) {
    switch (status) {
      case 'paid':
        return 'ชำระแล้ว';
      case 'pending':
        return 'รอตรวจสอบ';
      case 'rejected':
        return 'ไม่ผ่าน';
      default:
        return 'ยังไม่ชำระ';
    }
  }

  String _paymentMethodLabel(String method) {
    switch (method) {
      case 'promptpay':
        return 'PromptPay';
      case 'cash':
        return 'เงินสด';
      default:
        return 'ไม่ระบุ (ออเดอร์เก่า)';
    }
  }
}

class _StatusActions extends StatelessWidget {
  final String status;
  final Future<void> Function(String status) onSelected;

  const _StatusActions({required this.status, required this.onSelected});

  @override
  Widget build(BuildContext context) {
    final actions = status == 'pending'
        ? const [('กำลังเตรียมอาหาร', 'cooking')]
        : status == 'cooking'
        ? const [('อาหารพร้อมเสิร์ฟ', 'ready')]
        : status == 'ready'
        ? const [('จัดส่งสำเร็จ', 'done')]
        : const <(String, String)>[];

    if (actions.isEmpty) return const SizedBox.shrink();
    return GridView.count(
      crossAxisCount: 2,
      crossAxisSpacing: 14,
      mainAxisSpacing: 12,
      childAspectRatio: 3.8,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      children: actions
          .map(
            (action) => TextButton(
              onPressed: () => onSelected(action.$2),
              style: TextButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: const Color(0xFF201D1B),
                padding: const EdgeInsets.symmetric(horizontal: 8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  action.$1,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
            ),
          )
          .toList(),
    );
  }
}
