import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../services/authentication_service.dart';

// State ที่ UI ทั้งแอปฟังอยู่ (login/logout, role) ไม่คุยกับ Firebase ตรงๆ
// แต่เรียกผ่าน AuthenticationService เท่านั้น
class AuthProvider extends ChangeNotifier {
  final AuthenticationService _authService = AuthenticationService();

  User? _user;
  String? _role; // "customer" | "seller" | null (ยังไม่ login)
  bool _isLoading = false;

  User? get user => _user;
  String? get role => _role;
  bool get isLoggedIn => _user != null;
  bool get isLoading => _isLoading;

  AuthProvider() {
    _authService.authStateChanges.listen(_onAuthChanged);
  }

  Future<void> _onAuthChanged(User? user) async {
    _user = user;
    if (user != null) {
      _role = await _authService.fetchUserRole(user.uid);
    } else {
      _role = null;
    }
    notifyListeners(); // ทุก widget ที่ watch<AuthProvider>() จะ rebuild ทันที
  }

  Future<String?> login(String email, String password) async {
    _isLoading = true;
    notifyListeners();
    final error = await _authService.login(email, password);
    _isLoading = false;
    notifyListeners();
    return error;
  }

  Future<String?> register(String email, String password, String role) async {
    _isLoading = true;
    notifyListeners();
    final error = await _authService.register(email, password, role);
    _isLoading = false;
    notifyListeners();
    return error;
  }

  Future<void> logout() async => await _authService.logout();
}
