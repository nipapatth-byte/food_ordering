import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

// รับผิดชอบแค่การคุยกับ Firebase Auth + สร้าง user doc ใน Firestore เท่านั้น
// ไม่ยุ่งกับ UI เลย
class AuthenticationService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  Stream<User?> get authStateChanges => _auth.authStateChanges();

  String? get currentUserId => _auth.currentUser?.uid;
  User? get currentUser => _auth.currentUser;

  Future<String?> login(String email, String password) async {
    try {
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      return null; // สำเร็จ
    } on FirebaseAuthException catch (e) {
      return e.message ?? 'เข้าสู่ระบบไม่สำเร็จ';
    }
  }

  Future<String?> register(String email, String password, String role) async {
    try {
      final cred = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      // สร้าง document เก็บ role ไว้ที่ users/{uid}
      await _db.collection('users').doc(cred.user!.uid).set({
        'email': email,
        'role': role,
      });
      return null;
    } on FirebaseAuthException catch (e) {
      return e.message ?? 'สมัครสมาชิกไม่สำเร็จ';
    }
  }

  Future<void> logout() async => await _auth.signOut();

  // ดึง role ของ user จาก Firestore
  Future<String> fetchUserRole(String uid) async {
    final doc = await _db.collection('users').doc(uid).get();
    return doc.data()?['role'] ?? 'customer';
  }
}
