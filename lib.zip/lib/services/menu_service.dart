import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../models/menu_item_model.dart';

class MenuService {
  final _db = FirebaseFirestore.instance;

  // ---------- ส่วนเมนูจริงของร้าน (เก็บใน Firestore) ----------

  // ฟังเมนูทั้งหมดแบบ real-time (ถ้าร้านแก้ไข/เพิ่มเมนู ทุกเครื่องที่เปิดอยู่จะเห็นทันที)
  Stream<List<MenuItemModel>> streamAllMenu() {
    return _db
        .collection('menu_items')
        .snapshots()
        .map(
          (snap) => snap.docs
              .map((doc) => MenuItemModel.fromMap(doc.id, doc.data()))
              .toList(),
        );
  }

  // ฟังเมนูเฉพาะหมวดหมู่
  Stream<List<MenuItemModel>> streamMenuByCategory(String category) {
    return _db
        .collection('menu_items')
        .where('category', isEqualTo: category)
        .snapshots()
        .map(
          (snap) => snap.docs
              .map((doc) => MenuItemModel.fromMap(doc.id, doc.data()))
              .toList(),
        );
  }

  // เพิ่มเมนูใหม่ (ฝั่งร้านค้าใช้)
  Future<void> addMenuItem(MenuItemModel item) async {
    await _db.collection('menu_items').add(item.toMap());
  }

  // แก้ไขเมนู
  Future<void> updateMenuItem(String id, Map<String, dynamic> data) async {
    await _db.collection('menu_items').doc(id).update(data);
  }

  // ลบเมนู
  Future<void> deleteMenuItem(String id) async {
    await _db.collection('menu_items').doc(id).delete();
  }

  // ---------- ส่วน TheMealDB API (สุ่มเมนูแนะนำ "Today's Special") ----------
  // หมายเหตุ: อันนี้แค่ดึงมาโชว์เป็นแรงบันดาลใจ/รูปประกอบ ไม่เกี่ยวกับเมนูจริงของร้านใน Firestore

  Future<Map<String, dynamic>?> fetchTodaysSpecial() async {
    try {
      final response = await http.get(
        Uri.parse('https://www.themealdb.com/api/json/v1/1/random.php'),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final meal = data['meals']?[0];
        if (meal == null) return null;
        return {
          'name': meal['strMeal'] ?? '',
          'imageUrl': meal['strMealThumb'] ?? '',
          'category': meal['strCategory'] ?? '',
          'instructions': meal['strInstructions'] ?? '',
        };
      }
      return null;
    } catch (e) {
      // ไม่มีเน็ต หรือ API ล่ม -> คืน null ให้ UI แสดง fallback เอง
      return null;
    }
  }
}
