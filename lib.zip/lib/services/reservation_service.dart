import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/table_model.dart';
import '../models/reservation_model.dart';

class ReservationService {
  final _db = FirebaseFirestore.instance;

  // Stream โต๊ะทั้งหมด แบบ real-time เรียงตามหมายเลขโต๊ะ
  Stream<List<TableModel>> streamTables() {
    return _db
        .collection('tables')
        .orderBy('tableNumber')
        .snapshots()
        .map(
          (snap) => snap.docs
              .map((doc) => TableModel.fromMap(doc.id, doc.data()))
              .toList(),
        );
  }

  // จองโต๊ะแบบปลอดภัยจาก race condition ด้วย transaction
  // ถ้า 2 คนกดพร้อมกัน คนแรกจะผ่าน คนที่สองจะได้ error กลับไปทันที
  Future<String?> reserveTable({
    required String tableId,
    required String userId,
    required int partySize,
  }) async {
    final tableRef = _db.collection('tables').doc(tableId);

    try {
      await _db.runTransaction((transaction) async {
        final snapshot = await transaction.get(tableRef);

        if (!snapshot.exists) {
          throw Exception('ไม่พบโต๊ะนี้');
        }

        final currentStatus = snapshot.get('status');
        if (currentStatus != 'available') {
          throw Exception('โต๊ะนี้ถูกจองไปแล้ว กรุณาเลือกโต๊ะอื่น');
        }

        // อัปเดตสถานะโต๊ะ
        transaction.update(tableRef, {'status': 'reserved'});

        // สร้างเอกสารการจอง
        final reservationRef = _db.collection('reservations').doc();
        transaction.set(reservationRef, {
          'userId': userId,
          'tableId': tableId,
          'partySize': partySize,
          'status': 'confirmed',
          'reservedAt': FieldValue.serverTimestamp(),
        });
      });
      return null; // สำเร็จ ไม่มี error
    } catch (e) {
      return e.toString().replaceAll('Exception: ', '');
    }
  }

  // ฝั่ง user: ดูการจองของตัวเอง แบบ real-time
  Stream<List<ReservationModel>> streamMyReservations(String userId) {
    return _db
        .collection('reservations')
        .where('userId', isEqualTo: userId)
        .snapshots()
        .map((snap) {
          final reservations = snap.docs
              .map((doc) => ReservationModel.fromMap(doc.id, doc.data()))
              .toList();
          _sortReservations(reservations);
          return reservations;
        });
  }

  Stream<List<ReservationModel>> streamAllReservations() {
    return _db.collection('reservations').snapshots().map((snap) {
      final reservations = snap.docs
          .map((doc) => ReservationModel.fromMap(doc.id, doc.data()))
          .toList();
      _sortReservations(reservations);
      return reservations;
    });
  }

  void _sortReservations(List<ReservationModel> reservations) {
    reservations.sort((a, b) {
      final aDate = a.reservedAt ?? DateTime.fromMillisecondsSinceEpoch(0);
      final bDate = b.reservedAt ?? DateTime.fromMillisecondsSinceEpoch(0);
      return bDate.compareTo(aDate);
    });
  }

  Future<void> updateReservationStatus(
    String reservationId,
    String tableId,
    String status,
  ) async {
    final reservationRef = _db.collection('reservations').doc(reservationId);
    final tableRef = _db.collection('tables').doc(tableId);

    await _db.runTransaction((transaction) async {
      transaction.update(reservationRef, {'status': status});
      if (status == 'cancelled' || status == 'completed') {
        transaction.update(tableRef, {'status': 'available'});
      } else if (status == 'confirmed') {
        transaction.update(tableRef, {'status': 'reserved'});
      }
    });
  }

  // ยกเลิกการจอง -> ต้องคืนสถานะโต๊ะกลับเป็น available ด้วย (ใช้ transaction เหมือนกัน)
  Future<void> cancelReservation(String reservationId, String tableId) async {
    final reservationRef = _db.collection('reservations').doc(reservationId);
    final tableRef = _db.collection('tables').doc(tableId);

    await _db.runTransaction((transaction) async {
      transaction.update(reservationRef, {'status': 'cancelled'});
      transaction.update(tableRef, {'status': 'available'});
    });
  }
}
