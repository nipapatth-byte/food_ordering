import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import 'customer/customer_shell.dart';
import 'seller/seller_shell.dart';

// ตัวตัดสินใจว่าจะโชว์แอปฝั่งลูกค้า หรือฝั่งร้านค้า
// ทำงานอัตโนมัติ: พอ role เปลี่ยน (login/logout/register) จะสลับ shell ทั้งแอปทันที
class MainScaffold extends StatelessWidget {
  const MainScaffold({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    // ยังไม่ login หรือ login แล้วเป็นลูกค้า -> เห็น shell ลูกค้า (guest ก็ดูเมนู/โต๊ะได้)
    if (auth.role == 'seller') {
      return const SellerShell();
    }
    return const CustomerShell();
  }
}
