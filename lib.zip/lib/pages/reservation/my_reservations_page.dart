import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/reservation_model.dart';
import '../../services/reservation_service.dart';
import '../../providers/auth_provider.dart';
import '../../providers/reservation_provider.dart';

class MyReservationsPage extends StatelessWidget {
  const MyReservationsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final userId = auth.user?.uid;

    if (userId == null) {
      return const Center(child: Text('กรุณาเข้าสู่ระบบเพื่อดูการจองของคุณ'));
    }

    final service = ReservationService();

    return StreamBuilder<List<ReservationModel>>(
      stream: service.streamMyReservations(userId),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        final reservations = snapshot.data ?? [];
        if (reservations.isEmpty) {
          return const Center(child: Text('ยังไม่มีการจองโต๊ะ'));
        }

        return ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: reservations.length,
          itemBuilder: (context, index) {
            final r = reservations[index];
            return Card(
              child: ListTile(
                leading: const Icon(Icons.table_bar),
                title: Text('จำนวน ${r.partySize} คน'),
                subtitle: Text('สถานะ: ${r.status}'),
                trailing: r.status == 'confirmed'
                    ? TextButton(
                        onPressed: () async {
                          await context
                              .read<ReservationProvider>()
                              .cancelReservation(r.id, r.tableId);
                        },
                        child: const Text(
                          'ยกเลิก',
                          style: TextStyle(color: Colors.red),
                        ),
                      )
                    : null,
              ),
            );
          },
        );
      },
    );
  }
}
