import 'package:flutter/material.dart';
import 'table_layout_page.dart';
import 'my_reservations_page.dart';
import '../group_info_page.dart';

// หน้ารวมของระบบจองโต๊ะ เปิดจากปุ่ม/แบนเนอร์ในหน้าแรก มี tab ย่อยของตัวเอง 2 อัน
class ReservationShellEntry extends StatelessWidget {
  const ReservationShellEntry({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('จองโต๊ะ'),
          actions: [const GroupInfoAction()],
          bottom: const TabBar(
            tabs: [
              Tab(text: 'ผังโต๊ะ'),
              Tab(text: 'การจองของฉัน'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [TableLayoutPage(), MyReservationsPage()],
        ),
      ),
    );
  }
}
