import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/table_model.dart';
import '../../services/reservation_service.dart';
import '../../providers/auth_provider.dart';
import '../../providers/reservation_provider.dart';

class TableLayoutPage extends StatelessWidget {
  const TableLayoutPage({super.key});

  @override
  Widget build(BuildContext context) {
    final reservationService = ReservationService();
    final auth = context.watch<AuthProvider>();

    return StreamBuilder<List<TableModel>>(
      stream: reservationService
          .streamTables(), // real-time: โต๊ะไหนถูกจองไป UI จะเปลี่ยนสีทันที
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        final tables = snapshot.data ?? [];
        if (tables.isEmpty) {
          return const Center(child: Text('ยังไม่มีข้อมูลโต๊ะ'));
        }

        return GridView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: tables.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
          ),
          itemBuilder: (context, index) {
            final table = tables[index];
            final isAvailable = table.status == 'available';

            return GestureDetector(
              onTap: isAvailable
                  ? () => _showReserveDialog(context, table, auth.user?.uid)
                  : null,
              child: Container(
                decoration: BoxDecoration(
                  color: isAvailable
                      ? Colors.green.shade100
                      : Colors.red.shade100,
                  border: Border.all(
                    color: isAvailable ? Colors.green : Colors.red,
                    width: 2,
                  ),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.table_bar, size: 32),
                    Text(
                      'โต๊ะ ${table.tableNumber}',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    Text(
                      '${table.seatCount} ที่นั่ง',
                      style: const TextStyle(fontSize: 12),
                    ),
                    Text(
                      isAvailable ? 'ว่าง' : 'ไม่ว่าง',
                      style: TextStyle(
                        color: isAvailable
                            ? Colors.green.shade800
                            : Colors.red.shade800,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _showReserveDialog(
    BuildContext context,
    TableModel table,
    String? userId,
  ) {
    if (userId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('กรุณาเข้าสู่ระบบก่อนจองโต๊ะ')),
      );
      return;
    }

    int partySize = 2;
    showDialog(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setState) => AlertDialog(
          title: Text('จองโต๊ะ ${table.tableNumber}'),
          content: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                icon: const Icon(Icons.remove_circle_outline),
                onPressed: () => setState(
                  () => partySize = (partySize > 1) ? partySize - 1 : 1,
                ),
              ),
              Text('$partySize คน', style: const TextStyle(fontSize: 18)),
              IconButton(
                icon: const Icon(Icons.add_circle_outline),
                onPressed: () => setState(
                  () => partySize = (partySize < table.seatCount)
                      ? partySize + 1
                      : partySize,
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('ยกเลิก'),
            ),
            ElevatedButton(
              onPressed: () async {
                final reservationProvider = context.read<ReservationProvider>();
                final success = await reservationProvider.reserveTable(
                  tableId: table.id,
                  userId: userId,
                  partySize: partySize,
                );
                Navigator.pop(dialogContext);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      success
                          ? 'จองโต๊ะ ${table.tableNumber} สำเร็จ'
                          : reservationProvider.lastError ?? 'จองไม่สำเร็จ',
                    ),
                    backgroundColor: success ? Colors.green : Colors.red,
                  ),
                );
              },
              child: const Text('ยืนยันจอง'),
            ),
          ],
        ),
      ),
    );
  }
}
