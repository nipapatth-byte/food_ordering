import 'package:flutter/material.dart';
import '../../models/menu_item_model.dart';
import '../../services/menu_service.dart';
import '../group_info_page.dart';

class ManageMenuTab extends StatelessWidget {
  const ManageMenuTab({super.key});

  @override
  Widget build(BuildContext context) {
    final menuService = MenuService();

    return Scaffold(
      appBar: AppBar(
        title: const Text('จัดการเมนู'),
        actions: [const GroupInfoAction()],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showEditDialog(context, menuService, null),
        child: const Icon(Icons.add),
      ),
      body: StreamBuilder<List<MenuItemModel>>(
        stream: menuService.streamAllMenu(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final items = snapshot.data ?? [];
          if (items.isEmpty) {
            return const Center(
              child: Text('ยังไม่มีเมนู กดปุ่ม + เพื่อเพิ่ม'),
            );
          }
          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: items.length,
            itemBuilder: (context, index) {
              final item = items[index];
              return Card(
                child: ListTile(
                  leading: item.imageUrl.isNotEmpty
                      ? Image.network(
                          item.imageUrl,
                          width: 50,
                          height: 50,
                          fit: BoxFit.cover,
                        )
                      : const Icon(Icons.fastfood),
                  title: Text(item.name),
                  subtitle: Text(
                    '${item.category} - ${item.price.toStringAsFixed(0)} บาท',
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit, color: Colors.blue),
                        onPressed: () =>
                            _showEditDialog(context, menuService, item),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () => menuService.deleteMenuItem(item.id),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  void _showEditDialog(
    BuildContext context,
    MenuService service,
    MenuItemModel? existing,
  ) {
    final nameCtrl = TextEditingController(text: existing?.name ?? '');
    final priceCtrl = TextEditingController(
      text: existing?.price.toString() ?? '',
    );
    final categoryCtrl = TextEditingController(text: existing?.category ?? '');
    final imageCtrl = TextEditingController(text: existing?.imageUrl ?? '');
    final descCtrl = TextEditingController(text: existing?.description ?? '');

    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(existing == null ? 'เพิ่มเมนูใหม่' : 'แก้ไขเมนู'),
        content: SingleChildScrollView(
          child: Column(
            children: [
              TextField(
                controller: nameCtrl,
                decoration: const InputDecoration(labelText: 'ชื่อเมนู'),
              ),
              TextField(
                controller: priceCtrl,
                decoration: const InputDecoration(labelText: 'ราคา'),
                keyboardType: TextInputType.number,
              ),
              TextField(
                controller: categoryCtrl,
                decoration: const InputDecoration(labelText: 'หมวดหมู่'),
              ),
              TextField(
                controller: imageCtrl,
                decoration: const InputDecoration(labelText: 'URL รูปภาพ'),
              ),
              TextField(
                controller: descCtrl,
                decoration: const InputDecoration(labelText: 'คำอธิบาย'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('ยกเลิก'),
          ),
          ElevatedButton(
            onPressed: () async {
              final data = {
                'name': nameCtrl.text.trim(),
                'price': double.tryParse(priceCtrl.text.trim()) ?? 0,
                'category': categoryCtrl.text.trim(),
                'imageUrl': imageCtrl.text.trim(),
                'description': descCtrl.text.trim(),
              };
              if (existing == null) {
                await service.addMenuItem(
                  MenuItemModel(
                    id: '',
                    name: data['name'] as String,
                    price: data['price'] as double,
                    category: data['category'] as String,
                    imageUrl: data['imageUrl'] as String,
                    description: data['description'] as String,
                  ),
                );
              } else {
                await service.updateMenuItem(existing.id, data);
              }
              if (dialogContext.mounted) Navigator.pop(dialogContext);
            },
            child: const Text('บันทึก'),
          ),
        ],
      ),
    );
  }
}
