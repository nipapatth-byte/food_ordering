import 'package:flutter/material.dart';
import 'incoming_orders_tab.dart';
import 'manage_menu_tab.dart';
import 'manage_tables_tab.dart';
import '../customer/profile_tab.dart'; // ใช้ตัวเดิมได้เลย เพราะมันเช็ค role/logout ในตัวอยู่แล้ว
import 'manage_reservations_tab.dart';

class SellerShell extends StatefulWidget {
  const SellerShell({super.key});

  @override
  State<SellerShell> createState() => _SellerShellState();
}

class _SellerShellState extends State<SellerShell> {
  int _index = 0;

  final _pages = const [
    IncomingOrdersTab(),
    ManageMenuTab(),
    ManageTablesTab(),
    ManageReservationsTab(),
    ProfileTab(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _index, children: _pages),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
        type: BottomNavigationBarType.fixed,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.inbox),
            label: 'ออเดอร์เข้า',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.restaurant_menu),
            label: 'จัดการเมนู',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.table_bar),
            label: 'จัดการโต๊ะ',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.event_available),
            label: 'การจอง',
          ),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'โปรไฟล์'),
        ],
      ),
    );
  }
}
