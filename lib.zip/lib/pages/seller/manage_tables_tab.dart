import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../models/table_model.dart';
import '../../services/reservation_service.dart';
import '../group_info_page.dart';

// ฝั่งร้านค้าเพิ่ม/ลบโต๊ะ และดูภาพรวมว่าโต๊ะไหนไม่ว่างบ้าง (real-time)
class ManageTablesTab extends StatelessWidget {
  const ManageTablesTab({super.key});

  @override
  Widget build(BuildContext context) {
    final service = ReservationService();

    return Scaffold(
      appBar: AppBar(
        title: const Text('จัดการโต๊ะ'),
        actions: [const GroupInfoAction()],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddTableDialog(context),
        child: const Icon(Icons.add),
      ),
      body: StreamBuilder<List<TableModel>>(
        stream: service.streamTables(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final tables = snapshot.data ?? [];
          if (tables.isEmpty) {
            return const Center(
              child: Text('ยังไม่มีโต๊ะ กดปุ่ม + เพื่อเพิ่ม'),
            );
          }
          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: tables.length,
            itemBuilder: (context, index) {
              final table = tables[index];
              return Card(
                child: ListTile(
                  leading: const Icon(Icons.table_bar),
                  title: Text(
                    'โต๊ะ ${table.tableNumber} (${table.seatCount} ที่นั่ง)',
                  ),
                  subtitle: Text('สถานะ: ${table.status}'),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () => FirebaseFirestore.instance
                        .collection('tables')
                        .doc(table.id)
                        .delete(),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  void _showAddTableDialog(BuildContext context) {
    final numberCtrl = TextEditingController();
    final seatCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('เพิ่มโต๊ะใหม่'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: numberCtrl,
              decoration: const InputDecoration(labelText: 'หมายเลขโต๊ะ'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: seatCtrl,
              decoration: const InputDecoration(labelText: 'จำนวนที่นั่ง'),
              keyboardType: TextInputType.number,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('ยกเลิก'),
          ),
          ElevatedButton(
            onPressed: () async {
              await FirebaseFirestore.instance.collection('tables').add({
                'tableNumber': int.tryParse(numberCtrl.text.trim()) ?? 0,
                'seatCount': int.tryParse(seatCtrl.text.trim()) ?? 0,
                'status': 'available',
              });
              if (dialogContext.mounted) Navigator.pop(dialogContext);
            },
            child: const Text('บันทึก'),
          ),
        ],
      ),
    );
  }
}
