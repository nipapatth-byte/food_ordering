import 'package:flutter/material.dart';
import '../../models/order_model.dart';
import '../../services/order_service.dart';
import '../../widgets/order_status_badge.dart';
import '../group_info_page.dart';

// หน้านี้คือจุดที่ "คนขายกดปุ่มอัปเดตสถานะ แล้วแจ้งเตือนไปหา user แบบเรียลไทม์"
// เพราะ order_history_tab.dart ฝั่ง user ฟัง stream เดียวกันของ order เดียวกันอยู่
class IncomingOrdersTab extends StatelessWidget {
  const IncomingOrdersTab({super.key});

  @override
  Widget build(BuildContext context) {
    final orderService = OrderService();

    return Scaffold(
      appBar: AppBar(
        title: const Text('ออเดอร์เข้าใหม่'),
        actions: [const GroupInfoAction()],
      ),
      body: StreamBuilder<List<OrderModel>>(
        stream: orderService
            .streamActiveOrders(), // real-time: ออเดอร์ใหม่จาก user จะโผล่ทันที
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final orders = snapshot.data ?? [];
          if (orders.isEmpty) {
            return const Center(child: Text('ยังไม่มีออเดอร์เข้า'));
          }
          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: orders.length,
            itemBuilder: (context, index) {
              final order = orders[index];
              return Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'ออเดอร์ #${order.id.substring(0, 6)}',
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          OrderStatusBadge(status: order.status),
                        ],
                      ),
                      const Divider(),
                      ...order.items.map(
                        (item) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 2),
                          child: Text('${item['name']} x${item['qty']}'),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'รวม ${order.totalPrice.toStringAsFixed(0)} บาท',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 12),
                      _buildActionButton(context, orderService, order),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  // ปุ่มจะเปลี่ยนไปตามสถานะปัจจุบัน: pending -> cooking -> done
  Widget _buildActionButton(
    BuildContext context,
    OrderService service,
    OrderModel order,
  ) {
    if (order.status == 'pending') {
      return SizedBox(
        width: double.infinity,
        child: ElevatedButton.icon(
          icon: const Icon(Icons.local_fire_department),
          label: const Text('เริ่มทำอาหาร'),
          onPressed: () => service.updateStatus(order.id, 'cooking'),
        ),
      );
    }
    if (order.status == 'cooking') {
      return SizedBox(
        width: double.infinity,
        child: ElevatedButton.icon(
          icon: const Icon(Icons.check_circle),
          label: const Text('ทำเสร็จแล้ว'),
          style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
          onPressed: () => service.updateStatus(order.id, 'done'),
        ),
      );
    }
    return const SizedBox.shrink();
  }
}
