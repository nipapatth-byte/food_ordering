import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/order_model.dart';
import '../../services/order_service.dart';
import '../../providers/auth_provider.dart';
import '../../widgets/order_status_badge.dart';
import '../group_info_page.dart';

class OrderHistoryTab extends StatelessWidget {
  const OrderHistoryTab({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final userId = auth.user?.uid;

    return Scaffold(
      appBar: AppBar(
        title: const Text('คำสั่งซื้อของฉัน'),
        actions: [const GroupInfoAction()],
      ),
      body: userId == null
          ? const Center(
              child: Text(
                'กรุณาเข้าสู่ระบบเพื่อดูประวัติคำสั่งซื้อ (ไปที่แท็บโปรไฟล์)',
              ),
            )
          : StreamBuilder<List<OrderModel>>(
              // stream นี้จะอัปเดตทันทีเมื่อฝั่งร้านค้ากดเปลี่ยนสถานะ ไม่ต้องกด refresh เอง
              stream: OrderService().streamMyOrders(userId),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return Center(
                    child: Text('โหลดประวัติไม่สำเร็จ: ${snapshot.error}'),
                  );
                }
                final orders = snapshot.data ?? [];
                if (orders.isEmpty) {
                  return const Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.receipt_long,
                          size: 68,
                          color: Color(0xFFC62828),
                        ),
                        SizedBox(height: 12),
                        Text(
                          'ยังไม่มีประวัติคำสั่งซื้อ',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        SizedBox(height: 6),
                        Text('รายการสั่งซื้อของคุณจะแสดงที่นี่'),
                      ],
                    ),
                  );
                }
                return ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: orders.length,
                  itemBuilder: (context, index) {
                    final order = orders[index];
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 12.0),
                      child: Card(
                        child: ExpansionTile(
                          shape: const RoundedRectangleBorder(),
                          collapsedShape: const RoundedRectangleBorder(),
                          iconColor: const Color(0xFFC62828),
                          collapsedIconColor: const Color(0xFFC62828),
                          title: Text('ออเดอร์ #${order.id.substring(0, 6)}'),
                          subtitle: Text(
                            'รวม ${order.totalPrice.toStringAsFixed(0)} บาท',
                          ),
                          trailing: OrderStatusBadge(status: order.status),
                          children: order.items.map((item) {
                            return ListTile(
                              dense: true,
                              title: Text(item['name'] ?? ''),
                              trailing: Text('x${item['qty']}'),
                            );
                          }).toList(),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}
