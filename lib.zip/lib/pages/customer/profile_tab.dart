import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../group_info_page.dart';

// หน้านี้ทำหน้าที่ 2 อย่าง:
// - ยังไม่ login -> โชว์ฟอร์ม login/register (เลือก role ตอน register)
// - login แล้ว -> โชว์ข้อมูลผู้ใช้ + ปุ่ม logout
class ProfileTab extends StatefulWidget {
  const ProfileTab({super.key});

  @override
  State<ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends State<ProfileTab> {
  final _emailCtrl = TextEditingController();
  final _passCtrl = TextEditingController();
  String _selectedRole = 'customer';
  bool _isRegisterMode = false;
  String? _errorText;

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('โปรไฟล์'),
        actions: [const GroupInfoAction()],
      ),
      body: auth.isLoggedIn ? _buildLoggedInView(auth) : _buildAuthForm(auth),
    );
  }

  Widget _buildLoggedInView(AuthProvider auth) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: const Color(0xFFC62828),
            borderRadius: BorderRadius.circular(22),
          ),
          child: Column(
            children: [
              const CircleAvatar(
                radius: 42,
                backgroundColor: Colors.white,
                foregroundColor: Color(0xFFC62828),
                child: Icon(Icons.person, size: 42),
              ),
              const SizedBox(height: 14),
              Text(
                auth.user?.email ?? '',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Chip(
                label: Text(auth.role == 'seller' ? 'ร้านค้า' : 'ลูกค้า'),
                backgroundColor: Colors.white,
                labelStyle: const TextStyle(
                  color: Color(0xFFC62828),
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        Card(
          child: ListTile(
            leading: const CircleAvatar(
              backgroundColor: Color(0xFFFFE1E1),
              foregroundColor: Color(0xFFC62828),
              child: Icon(Icons.verified_user_outlined),
            ),
            title: const Text(
              'บัญชีของฉัน',
              style: TextStyle(fontWeight: FontWeight.w800),
            ),
            subtitle: const Text('จัดการข้อมูลและการเข้าสู่ระบบ'),
            trailing: const Icon(Icons.chevron_right, color: Color(0xFFC62828)),
          ),
        ),
        const SizedBox(height: 20),
        OutlinedButton.icon(
          onPressed: () => auth.logout(),
          icon: const Icon(Icons.logout),
          label: const Text('ออกจากระบบ'),
          style: OutlinedButton.styleFrom(
            foregroundColor: const Color(0xFFC62828),
            side: const BorderSide(color: Color(0xFFC62828)),
            minimumSize: const Size.fromHeight(50),
          ),
        ),
      ],
    );
  }

  Widget _buildAuthForm(AuthProvider auth) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          Text(
            _isRegisterMode ? 'สมัครสมาชิก' : 'เข้าสู่ระบบ',
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),
          TextField(
            controller: _emailCtrl,
            keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(
              labelText: 'อีเมล',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _passCtrl,
            obscureText: true,
            decoration: const InputDecoration(
              labelText: 'รหัสผ่าน',
              border: OutlineInputBorder(),
            ),
          ),
          if (_isRegisterMode) ...[
            const SizedBox(height: 16),
            const Align(
              alignment: Alignment.centerLeft,
              child: Text('สมัครเป็น:'),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: ChoiceChip(
                    label: const Text('ลูกค้า'),
                    selected: _selectedRole == 'customer',
                    onSelected: (_) =>
                        setState(() => _selectedRole = 'customer'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ChoiceChip(
                    label: const Text('ร้านค้า'),
                    selected: _selectedRole == 'seller',
                    onSelected: (_) => setState(() => _selectedRole = 'seller'),
                  ),
                ),
              ],
            ),
          ],
          if (_errorText != null) ...[
            const SizedBox(height: 12),
            Text(_errorText!, style: const TextStyle(color: Colors.red)),
          ],
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: auth.isLoading
                  ? null
                  : () async {
                      final email = _emailCtrl.text.trim();
                      final pass = _passCtrl.text.trim();
                      final error = _isRegisterMode
                          ? await auth.register(email, pass, _selectedRole)
                          : await auth.login(email, pass);
                      setState(() => _errorText = error);
                    },
              child: auth.isLoading
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : Text(_isRegisterMode ? 'สมัครสมาชิก' : 'เข้าสู่ระบบ'),
            ),
          ),
          TextButton(
            onPressed: () => setState(() {
              _isRegisterMode = !_isRegisterMode;
              _errorText = null;
            }),
            child: Text(
              _isRegisterMode
                  ? 'มีบัญชีแล้ว? เข้าสู่ระบบ'
                  : 'ยังไม่มีบัญชี? สมัครสมาชิก',
            ),
          ),
        ],
      ),
    );
  }
}
