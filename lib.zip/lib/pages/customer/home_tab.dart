import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/menu_item_model.dart';
import '../../providers/cart_provider.dart';
import '../../services/menu_service.dart';
import 'cart_tab.dart';

class HomeTab extends StatefulWidget {
  final VoidCallback? onProfileTap;

  const HomeTab({super.key, this.onProfileTap});

  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  final MenuService _menuService = MenuService();
  Map<String, dynamic>? _todaysSpecial;
  bool _loadingSpecial = true;
  String _selectedCategory = 'ทั้งหมด';

  static const _categories = ['ทั้งหมด', 'อาหารจานหลัก', 'ของหวาน', 'เครื่องดื่ม'];

  @override
  void initState() {
    super.initState();
    _loadTodaysSpecial();
  }

  Future<void> _loadTodaysSpecial() async {
    final special = await _menuService.fetchTodaysSpecial();
    if (mounted) {
      setState(() {
        _todaysSpecial = special;
        _loadingSpecial = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(),
      body: RefreshIndicator(
        onRefresh: _loadTodaysSpecial,
        color: const Color(0xFFE6391A),
        child: CustomScrollView(
          slivers: [
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(24, 4, 24, 0),
              sliver: SliverToBoxAdapter(child: _buildTodaysSpecial()),
            ),
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.fromLTRB(24, 22, 24, 12),
                child: Text('เมนูยอดฮิต 🔥', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
              ),
            ),
            SliverToBoxAdapter(child: _buildCategoryChips()),
            _buildMenuGrid(),
          ],
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() => AppBar(
    automaticallyImplyLeading: false,
    titleSpacing: 20,
    title: Row(
      children: [
        Image.asset('lib/assests/images/logo.png', width: 38, height: 38),
        const SizedBox(width: 10),
        const Text('กินไรดี (Kin Rai Dee)'),
      ],
    ),
    actions: [
      IconButton(tooltip: 'โปรไฟล์', onPressed: widget.onProfileTap, icon: const Icon(Icons.person_outline)),
      Consumer<CartProvider>(
        builder: (context, cart, child) => Badge(
          isLabelVisible: cart.itemCount > 0,
          label: Text('${cart.itemCount}'),
          backgroundColor: const Color(0xFFE6391A),
          child: IconButton(
            tooltip: 'ตะกร้า',
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CartTab())),
            icon: const Icon(Icons.shopping_cart_outlined),
          ),
        ),
      ),
      const SizedBox(width: 12),
    ],
  );

  Widget _buildCategoryChips() => SizedBox(
    height: 44,
    child: ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      scrollDirection: Axis.horizontal,
      itemCount: _categories.length,
      separatorBuilder: (_, index) => const SizedBox(width: 8),
      itemBuilder: (context, index) {
        final category = _categories[index];
        final selected = category == _selectedCategory;
        return ChoiceChip(
          label: Text(category),
          selected: selected,
          onSelected: (_) => setState(() => _selectedCategory = category),
          selectedColor: const Color(0xFFE6391A),
          backgroundColor: const Color(0xFF201D1B),
          labelStyle: TextStyle(color: selected ? Colors.white : const Color(0xFFB8AAA5), fontWeight: FontWeight.w800),
          side: BorderSide(color: selected ? const Color(0xFFE6391A) : const Color(0xFF3C3531)),
        );
      },
    ),
  );

  Widget _buildMenuGrid() => StreamBuilder<List<MenuItemModel>>(
    stream: _menuService.streamAllMenu(),
    builder: (context, snapshot) {
      if (snapshot.connectionState == ConnectionState.waiting) {
        return const SliverFillRemaining(hasScrollBody: false, child: Center(child: CircularProgressIndicator()));
      }
      final items = (snapshot.data ?? []).where((item) => _selectedCategory == 'ทั้งหมด' || item.category == _selectedCategory).toList();
      if (items.isEmpty) {
        return const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.all(32), child: Center(child: Text('ยังไม่มีเมนูในหมวดนี้'))));
      }
      return SliverPadding(
        padding: const EdgeInsets.fromLTRB(24, 14, 24, 28),
        sliver: SliverGrid.builder(
          itemCount: items.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 14, childAspectRatio: 0.76),
          itemBuilder: (context, index) => _MenuTile(item: items[index]),
        ),
      );
    },
  );

  Widget _buildTodaysSpecial() {
    if (_loadingSpecial) {
      return const SizedBox(height: 190, child: Center(child: CircularProgressIndicator()));
    }
    if (_todaysSpecial == null) {
      return Container(
        height: 190,
        alignment: Alignment.center,
        decoration: BoxDecoration(color: const Color(0xFFE6391A), borderRadius: BorderRadius.circular(22)),
        child: const Text('อร่อยง่าย ได้ทุกวัน 🍜', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
      );
    }
    return Card(
      clipBehavior: Clip.antiAlias,
      margin: EdgeInsets.zero,
      child: SizedBox(
        height: 190,
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.network(
              _todaysSpecial!['imageUrl'],
              fit: BoxFit.cover,
              errorBuilder: (_, error, stackTrace) => const ColoredBox(color: Color(0xFF3B2922), child: Icon(Icons.restaurant, size: 64, color: Colors.white)),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.fromLTRB(16, 30, 16, 14),
                decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Colors.black87])),
                child: Text("Today's Special\n${_todaysSpecial!['name']}", maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MenuTile extends StatelessWidget {
  final MenuItemModel item;

  const _MenuTile({required this.item});

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: item.imageUrl.isEmpty
                ? const ColoredBox(
                    color: Color(0xFF3B2922),
                    child: Center(child: Icon(Icons.restaurant, size: 42)),
                  )
                : Image.network(
                    item.imageUrl,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    errorBuilder: (_, error, stackTrace) => const ColoredBox(
                      color: Color(0xFF3B2922),
                      child: Center(child: Icon(Icons.restaurant, size: 42)),
                    ),
                  ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 9, 6, 5),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900)),
                      const SizedBox(height: 3),
                      Text('${item.price.toStringAsFixed(0)} บาท', style: const TextStyle(color: Color(0xFFFF765E), fontWeight: FontWeight.w900)),
                    ],
                  ),
                ),
                IconButton(
                  tooltip: 'เพิ่มลงตะกร้า',
                  visualDensity: VisualDensity.compact,
                  onPressed: () {
                    context.read<CartProvider>().addItem(item);
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('เพิ่มลงตะกร้าแล้ว')));
                  },
                  icon: const Icon(Icons.add_circle, color: Color(0xFFE6391A)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
