class ReservationModel {
  final String id;
  final String userId;
  final String tableId;
  final int partySize;
  final String status; // confirmed | cancelled | completed
  final DateTime? reservedAt;

  ReservationModel({
    required this.id,
    required this.userId,
    required this.tableId,
    required this.partySize,
    required this.status,
    this.reservedAt,
  });

  factory ReservationModel.fromMap(String id, Map<String, dynamic> map) {
    return ReservationModel(
      id: id,
      userId: map['userId'] ?? '',
      tableId: map['tableId'] ?? '',
      partySize: map['partySize'] ?? 1,
      status: map['status'] ?? 'confirmed',
      reservedAt: map['reservedAt'] != null ? map['reservedAt'].toDate() : null,
    );
  }
}
