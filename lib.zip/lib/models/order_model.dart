class OrderModel {
  final String id;
  final String userId;
  final List<Map<String, dynamic>> items; // [{menuId, name, qty, priceAtOrder}]
  final String status; // pending | cooking | done
  final double totalPrice;
  final DateTime? createdAt;

  OrderModel({
    required this.id,
    required this.userId,
    required this.items,
    required this.status,
    required this.totalPrice,
    this.createdAt,
  });

  factory OrderModel.fromMap(String id, Map<String, dynamic> map) {
    return OrderModel(
      id: id,
      userId: map['userId'] ?? '',
      items: List<Map<String, dynamic>>.from(map['items'] ?? []),
      status: map['status'] ?? 'pending',
      totalPrice: (map['totalPrice'] ?? 0).toDouble(),
      createdAt: map['createdAt'] != null ? map['createdAt'].toDate() : null,
    );
  }
}
